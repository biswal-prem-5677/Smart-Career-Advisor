import google.generativeai as genai
import os
import json
from dotenv import load_dotenv

# Load env from backend/.env if not already loaded
# Load env from backend/.env if not already loaded
# Fix path resolution to be relative to this file
current_file_path = os.path.abspath(__file__)
src_dir = os.path.dirname(current_file_path)
project_root = os.path.dirname(src_dir)
backend_env_path = os.path.join(project_root, 'backend', '.env')

if os.path.exists(backend_env_path):
    load_dotenv(backend_env_path)
else:
    load_dotenv() # Fallback

import random
import time

# ... imports remain ...

# Load Keys
key_string = os.getenv("GEMINI_API_KEY", "")
API_KEYS = [k.strip() for k in key_string.split(',') if k.strip()]

if not API_KEYS:
    print("⚠️ GEMINI_API_KEY not found. AI features will fail.")

def configure_genai(api_key):
    genai.configure(api_key=api_key)

# Models to try in order of priority
MODELS = ["gemini-3-flash-preview", "gemini-3-flash", "gemini-1.5-flash"]

def get_ai_response(prompt, temperature=0.7):
    """
    Generates text with API key rotation AND Model Fallback on 429.
    """
    if not API_KEYS:
        return "Error: API Key missing."

    shuffled_keys = list(API_KEYS)
    random.shuffle(shuffled_keys)

    for i, key in enumerate(shuffled_keys):
        configure_genai(key)
        
        # Try fallbacks for this key
        for model_name in MODELS:
            try:
                # print(f"DEBUG: Trying Model: {model_name} with Key ending in ...{key[-4:]}")
                model = genai.GenerativeModel(model_name)
                response = model.generate_content(
                    prompt,
                    generation_config=genai.types.GenerationConfig(temperature=temperature)
                )
                return response.text
                
            except Exception as e:
                error_msg = str(e)
                print(f"❌ error: {e}")
                # Try next model on error
                continue
        
        # If all models failed for this key (likely key quota), try next key
        # print("⚠️ All models failed for this key. Switching key...")
        continue

    return "I'm currently receiving too many requests. Please try again in 30 seconds! ⏳"

def get_ai_json(prompt, temperature=0.5):
    """
    Generates JSON with API key rotation AND Model Fallback on 429.
    """
    if not API_KEYS:
        return {}

    shuffled_keys = list(API_KEYS)
    random.shuffle(shuffled_keys)

    for i, key in enumerate(shuffled_keys):
        configure_genai(key)
        
        for model_name in MODELS:
            try:
                model = genai.GenerativeModel(model_name)
                response = model.generate_content(
                    f"{prompt}\n\nIMPORTANT: Output ONLY valid JSON code. No markdown formatting.",
                    generation_config=genai.types.GenerationConfig(temperature=temperature)
                )
                
                text = response.text
                if text.startswith("```json"): text = text[7:]
                if text.endswith("```"): text = text[:-3]
                return json.loads(text.strip())
                
            except Exception as e:
                error_msg = str(e)
                print(f"❌ JSON error: {e}")
                continue
        
        continue

    return {"error": "quota_exceeded"}

def generate_company_prep_plan(company_type: str, company_name: str, time_period: str = "4 Weeks"):
    """
    Generates a structured preparation plan for a specific company with historical insights.
    """
    prompt = f"""
    Act as an experienced Placement Mentor.
    User is preparing for '{company_name}' ({company_type} based).

    1. **Hiring Trends (Last 3 Years)**: Analyze how '{company_name}' has hired recently (e.g., focus areas, difficulty level, rounds).
    2. **Frequent Topics**: Identify concepts and questions they ask repeatedly.
    3. **Plan**: Create a {time_period} tailored study plan.

    Structure the response as a JSON object with this exact schema:
    {{
        "insights": {{
            "hiring_trend": "Summary of {company_name}'s hiring pattern over the last 3 years.",
            "common_rounds": ["Round 1: Online Test", "Round 2: Technical"],
            "frequent_topics": ["Topic 1", "Topic 2"],
            "difficulty_level": "Medium-Hard"
        }},
        "weeks": [
            {{
                "week_number": 1,
                "theme": "Focus Area",
                "days": [
                    {{
                        "day": 1,
                        "topic": "Topic Name",
                        "subtopics": ["Sub 1", "Sub 2"],
                        "priority": "High",
                        "resources": ["Link/Book"],
                        "practice_question": "Specific question asked in {company_name} (if any)"
                    }}
                ]
            }}
        ]
    }}
    
    Ensure the plan is realistic and highly specific to {company_name} if possible.
    """
    return get_ai_json(prompt, temperature=0.7)
